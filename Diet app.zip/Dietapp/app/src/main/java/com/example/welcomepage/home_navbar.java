package com.example.welcomepage;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.welcomepage.ui.Person;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class home_navbar extends AppCompatActivity {

    Databaseyeni db;

    BottomNavigationView bottomNavigationView;
    ImageButton cikisbutonu;

    TextView adimsayar;
    SensorManager sensorManager;

    boolean running = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_navbar);

        db = new Databaseyeni(this);

        Intent dataintent = getIntent();

        Person persondata = (Person) getIntent().getSerializableExtra("data");

        String id = String.valueOf(persondata.getid());
        String name = persondata.getIsim();
        String email = persondata.getEmail();
        String guncelkilo =String.valueOf(persondata.getGuncelkilo()); //gelen data intti settex sadece string çalışıyor
        String idealkilo = String.valueOf(persondata.getIdealkilo());
        String datakalori = String.valueOf(persondata.getKalori());
        String soyisim = persondata.getSoyisim();
        String sifre = persondata.getSifre();
        String yas = String.valueOf(persondata.getYas());
        String cinsiyet = persondata.getCinsiyet();
        String boy = String.valueOf(persondata.getBoy());



        String isim = name;
        String kilo = guncelkilo;
        String ikilo = idealkilo;
        String kalori = datakalori;


        final Bundle bundobj = new Bundle();

        bundobj.putString("id",id);

        bundobj.putString("isim", isim);
        bundobj.putString("soyisim", soyisim);
        bundobj.putString("email", email);
        bundobj.putString("sifre", sifre);
        bundobj.putString("yas", yas);
        bundobj.putString("cinsiyet", cinsiyet);
        bundobj.putString("boy", boy);

        bundobj.putString("kilo", kilo);
        bundobj.putString("idealkilo", ikilo);
        bundobj.putString("kalori", kalori);






        bottomNavigationView = findViewById(R.id.bottomNav);

         homefragment fragment = new homefragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().add(R.id.fragmentContainer, fragment).commit();

        fragment.setArguments(bundobj);



        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                Fragment fr = null;

                switch (menuItem.getItemId()) {
                    case R.id.nav_home:
                        fr = new homefragment();
                        fr.setArguments(bundobj);
                        break;

                    case R.id.nav_adimsayar:
                        fr = new adimsayarfragment();

                        break;

                    case R.id.nav_kalori:
                        fr = new kalorifragment();
                        fr.setArguments(bundobj);

                        break;

                    case R.id.nav_profil:
                        fr = new profilfragment();
                        fr.setArguments(bundobj);

                        break;
                }

                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, fr).commit();

                return true;
            }
        });

    }
}



