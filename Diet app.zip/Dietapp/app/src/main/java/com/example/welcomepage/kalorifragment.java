package com.example.welcomepage;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.welcomepage.R;




public class kalorifragment extends Fragment {

    TextView tvalinankalori, tvlimitkalori;
    private View rootview;

    Databaseyeni db;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootview = inflater.inflate(R.layout.fragment_kalori_fragment, container, false);

        db= new Databaseyeni(this.getActivity());

        String alinankal = getArguments().getString("kalori");

        int boy = Integer.parseInt(getArguments().getString("boy"));
        int yas = Integer.parseInt(getArguments().getString("yas"));
        int kilo = Integer.parseInt(getArguments().getString("kilo"));

        int needcal = (int) (66+ (9.6*kilo)+(1.7*boy)+ (4.7*yas));

        String needcalori = String.valueOf(needcal);

        tvalinankalori= rootview.findViewById(R.id.tvdatakalori);
        tvlimitkalori = rootview.findViewById(R.id.tvgereklikalori);

        tvalinankalori.setText(alinankal);
        tvlimitkalori.setText(needcalori);



        return rootview;



    }
}
