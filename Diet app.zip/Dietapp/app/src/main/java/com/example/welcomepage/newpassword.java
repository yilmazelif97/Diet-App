package com.example.welcomepage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class newpassword extends AppCompatActivity {

    Button btnsave;
    EditText etmail, etnewpass;
    Databaseyeni db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newpassword);

        db= new Databaseyeni(this);

        btnsave = findViewById(R.id.btnnewpass);
        etmail = findViewById(R.id.etEmail);
        etnewpass = findViewById(R.id.etnewpass);



        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mail = etmail.getText().toString();
                String pass = etnewpass.getText().toString();

                boolean match = db.SearchMail(mail);

                if (match==true){

                    if (pass.isEmpty()){

                        Toast.makeText(getApplicationContext(),"Lütfen şifre girin", Toast.LENGTH_SHORT).show();

                    }else{

                        db.UpdatePassword(mail,pass);

                    }

                    Toast.makeText(getApplicationContext(),"Bilgileriniz Güncellendi", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(getApplicationContext(), "E-mailiniz hatalı", Toast.LENGTH_SHORT).show();
                }


            }
        });






    }
}
