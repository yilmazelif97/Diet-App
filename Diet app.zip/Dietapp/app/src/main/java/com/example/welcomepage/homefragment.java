package com.example.welcomepage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.welcomepage.R;
import com.example.welcomepage.ui.Person;


public class homefragment extends Fragment {

    TextView kullaniciadi, kilo, tvidealkilo;
    EditText gkilo;
    private View rootview;


    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){


        rootview = inflater.inflate(R.layout.fragment_home_fragment, container, false);


        String val = getArguments().getString("isim");
        String kilodata = getArguments().getString("kilo");
        String idkilo = getArguments().getString("idealkilo");

        kullaniciadi= rootview.findViewById(R.id.tvKullaniciAdi);
        kilo = rootview.findViewById(R.id.tvkilo);
        tvidealkilo= rootview.findViewById(R.id.tvidealkilo);


        kullaniciadi.setText(val);
        kilo.setText(kilodata);
        tvidealkilo.setText(idkilo);


        return rootview;




    }


}
