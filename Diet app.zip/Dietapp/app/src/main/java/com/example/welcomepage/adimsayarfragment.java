package com.example.welcomepage;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.welcomepage.R;


public class adimsayarfragment extends Fragment {

    TextView adimsayar;
    SensorManager sensorManager;

    boolean running = false;



    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView1 = inflater.inflate(R.layout.fragment_adimsayar_fragment, container, false);

       /* adimsayar = rootView1.findViewById(R.id.tvadimsayar);

        sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);


        if (savedInstanceState==null){
            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new adimsayarfragment()).commit();
        }*/


        return rootView1;
    }

   /* public void onResume() {
        super.onResume();
        running = true;
        Sensor countSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if(countSensor!= null){
            sensorManager.registerListener(this, countSensor, SensorManager.SENSOR_DELAY_UI);

        }
        else{
            Toast.makeText(getActivity(),"Adım Sayar Telefonda Çalışır Durumda",Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onPause() { //giriş yapılmadığında çalışmasını engellemek için
        super.onPause();
        running=false;
    }


    @Override
    public void onSensorChanged(SensorEvent event) {

        if (running){
            adimsayar.setText(String.valueOf(event.values[0]));
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }*/
}
