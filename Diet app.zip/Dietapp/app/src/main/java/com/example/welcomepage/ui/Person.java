package com.example.welcomepage.ui;

import java.io.Serializable;

public class Person implements Serializable {  //Objeyi kullanılabilir yapmak için bu kütüphaneyi implement ettim

    private int id;
    private String isim;
    private String soyisim;
    private String email;
    private String sifre;
    private int yas;
    private String cinsiyet;
    private int boy;
    private int guncelkilo;
    private int idealkilo;



    private int kalori;


    public Person(int id, String isim, String soyisim, String email, String sifre, int yas, String cinsiyet, int boy, int guncelkilo, int idealkilo,int kalori) {

        this.id=id;
        this.isim = isim;
        this.soyisim = soyisim;
        this.email = email;
        this.sifre = sifre;
        this.yas = yas;
        this.cinsiyet = cinsiyet;
        this.boy = boy;
        this.guncelkilo = guncelkilo;
        this.idealkilo=idealkilo;
        this.kalori = kalori;
    }

    public int getKalori() {
        return kalori;
    }

    public void setKalori(int kalori) {
        this.kalori = kalori;
    }


    public int getid() {
        return id;
    }
    public void setId(int id){
        this.id=id;
    }

    public void setIsim(int id) {
        this.id = id;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getSoyisim() {
        return soyisim;
    }

    public void setSoyisim(String soyisim) {
        this.soyisim = soyisim;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }

    public String getCinsiyet() {
        return cinsiyet;
    }

    public void setCinsiyet(String cinsiyet) {
        this.cinsiyet = cinsiyet;
    }

    public int getBoy() {
        return boy;
    }

    public void setBoy(int boy) {
        this.boy = boy;
    }

    public int getGuncelkilo() {
        return guncelkilo;
    }

    public void setGuncelkilo(int guncelkilo) {
        this.guncelkilo = guncelkilo;
    }

    public int getIdealkilo() {
        return idealkilo;
    }

    public void setIdealkilo(int idealkilo) {
        this.idealkilo = idealkilo;
    }



}
