package com.example.welcomepage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class uyeolma extends AppCompatActivity {

    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    SQLiteDatabase data;

    Button btnuyeolma;
    EditText etisim, etsoyisim, etemail, etsifre, etyas, etboy, etguncelkilo;
    RadioButton rbkadin, rberkek;
    RadioGroup rgcinsiyet;

    boolean erkek = false;
    int kadin = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uyeolma);

        openHelper = new Databaseyeni(this); // data için açtığım java classın ismi


        btnuyeolma = findViewById(R.id.btnuyeol);
        etisim = findViewById(R.id.etisim);
        etsoyisim = findViewById(R.id.etsoyisim);
        etemail = findViewById(R.id.etemail);
        etsifre = findViewById(R.id.etsifre);
        etyas = findViewById(R.id.etyas);
        etboy = findViewById(R.id.etboy);
        etguncelkilo = findViewById(R.id.etkilo);
        rbkadin = findViewById(R.id.rbkadin);
        rberkek = findViewById(R.id.rberkek);
        rgcinsiyet = findViewById(R.id.rgroupcinsiyet);

        rberkek.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (rberkek.isChecked()){
                    erkek=true;

                }
            }
        });


        btnuyeolma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                db = openHelper.getWritableDatabase();
                String dbisim = etisim.getText().toString();
                String dbsoyisim = etsoyisim.getText().toString();
                String dbemail = etemail.getText().toString();
                String dbsifre = etsifre.getText().toString();
                String dbyas = etyas.getText().toString();
                String dbboy = etboy.getText().toString();
                String dbguncelkilo = etguncelkilo.getText().toString();
                RadioButton checkbtn = findViewById(rgcinsiyet.getCheckedRadioButtonId());
                String cinsiyet = checkbtn.getText().toString();

                String idealkil = idealkilohesap();



                uyeekleme(dbisim, dbsoyisim, dbemail, dbsifre, dbyas, dbboy, dbguncelkilo, cinsiyet, idealkil);
                Toast.makeText(getApplicationContext(), "Üye olma başarılı", Toast.LENGTH_LONG).show();


            }
        });

    }

    public void uyeekleme(String dbisim, String dbsoyisim, String dbemail, String dbsifre, String dbyas, String dbboy, String dbguncelkilo, String cinsiyet, String idealkil) {


        ContentValues contentValues = new ContentValues();


        contentValues.put(Database.col2, dbisim);
        contentValues.put(Database.col3, dbsoyisim);
        contentValues.put(Database.col4, dbemail);
        contentValues.put(Database.col5, dbsifre);
        contentValues.put(Database.col6, dbyas);
        contentValues.put(Database.col7, cinsiyet);
        contentValues.put(Database.col8, dbboy);
        contentValues.put(Database.col9, dbguncelkilo);
        contentValues.put(Database.col10, idealkil);


        long id = db.insert(Databaseyeni.tablename, null, contentValues);


    }

    public String idealkilohesap() {

        RadioButton checkbtn = findViewById(rgcinsiyet.getCheckedRadioButtonId());
        int radioid = rgcinsiyet.getCheckedRadioButtonId();

        String cinsiyet = checkbtn.getText().toString();


        String dbboy = etboy.getText().toString();
        float boy = Float.parseFloat(dbboy);

        if (erkek==true){

            float inc = (float) (boy/2.54); // boy cm olarak giriliyor o yüzden burda hesaplamlar için inçe çevirdim


            int idealkiloerkek = (int) (50 + (2.3) * (inc - 60));

            String ikilo = String.valueOf(idealkiloerkek);
            return ikilo;
        }
        else{

            float inc = (float) (boy/2.54);
            int idealkilokadin = (int) ((45.5) + (2.3) * (inc - 60));
            String iikilo = String.valueOf(idealkilokadin);
            return iikilo;

        }

    }


    public boolean checkemailformat(String email) {

        Pattern pattern;
        Matcher matcher;
        String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();

    }



}
