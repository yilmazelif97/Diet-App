package com.example.welcomepage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import com.example.welcomepage.ui.Person;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;

import java.util.ArrayList;

public class Grafik extends AppCompatActivity {

    BarChart barchar;
    int [] Colorclass = new int[]{Color.RED, Color.BLUE};
    Databaseyeni db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafik);

        Intent intent = getIntent();

        final String email = (String) getIntent().getSerializableExtra("email");

        db= new Databaseyeni(this);

        barchar = findViewById(R.id.barchart);

        Person data = db.getInfo(email); //maile ait bilgileri alıyor

        int alinankalori = data.getKalori();

        String ad = data.getIsim();

        int yas = data.getYas();
        int boy = data.getBoy();
        int kilo = data.getGuncelkilo();

        int alinmasigerekenkal = (int) (66+ (9.6*kilo)+(1.7*boy)+ (4.7*yas));


        //Toast.makeText(getApplicationContext(),alinankl,Toast.LENGTH_SHORT).show();

        ArrayList<BarEntry> dataval = new ArrayList<>();
        dataval.add(new BarEntry(0,new float[]{alinankalori, alinmasigerekenkal}));
        dataval.add(new BarEntry(1,0));
        dataval.add(new BarEntry(3,6));

        BarDataSet barDataSet = new BarDataSet(dataval, "Kalori");
        barDataSet.setColors(Colorclass);



        BarData barData = new BarData();
        barData.addDataSet(barDataSet);

        barchar.setData(barData);
        barchar.invalidate();





    }

    private ArrayList<BarEntry> datavalues (){


        ArrayList<BarEntry> dataval = new ArrayList<>();
        dataval.add(new BarEntry(0,3));
        dataval.add(new BarEntry(1,4));
        dataval.add(new BarEntry(3,6));


        return dataval;

    }




}
