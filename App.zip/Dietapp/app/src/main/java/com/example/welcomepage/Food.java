package com.example.welcomepage;

import java.io.Serializable;

public class Food implements Serializable {

    private int foodid;
    private String foodname;
    private int kalori;

    public Food(int foodid, String foodname, int kalori) {
        this.foodid = foodid;
        this.foodname = foodname;
        this.kalori = kalori;
    }




    public int getFoodid() {
        return foodid;
    }

    public void setFoodid(int foodid) {
        this.foodid = foodid;
    }

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public int getKalori() {
        return kalori;
    }

    public void setKalori(int kalori) {
        this.kalori = kalori;
    }


}
