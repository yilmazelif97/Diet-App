package com.example.welcomepage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.welcomepage.R;
import com.example.welcomepage.ui.Person;


public class homefragment extends Fragment {

    TextView kullaniciadi, kilo, tvidealkilo;
    EditText gkilo;
    Button btnsabah;
    private View rootview;

    Databaseyeni db;


    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){


        rootview = inflater.inflate(R.layout.fragment_home_fragment, container, false);

        db =  new Databaseyeni(getActivity());

        String id = getArguments().getString("id");

        String val = getArguments().getString("isim");
        String kilodata = getArguments().getString("kilo");
        String idkilo = getArguments().getString("idealkilo");
        final String email = getArguments().getString("email");

        kullaniciadi= rootview.findViewById(R.id.tvKullaniciAdi);
        kilo = rootview.findViewById(R.id.tvkilo);
        tvidealkilo= rootview.findViewById(R.id.tvidealkilo);
        btnsabah = rootview.findViewById(R.id.btnSabah);

        btnsabah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent gecis = new Intent(getActivity(), Besinsearch.class);

                gecis.putExtra("email", email);

                startActivity(gecis);


            }
        });



        kullaniciadi.setText(val);
        kilo.setText(kilodata);
        tvidealkilo.setText(idkilo);




        return rootview;




    }


}
