package com.example.welcomepage;

import androidx.appcompat.app.AppCompatActivity;

import android.app.LauncherActivity;
import android.app.Person;
import android.app.SearchManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Besinsearch extends AppCompatActivity {

    SearchView searchviv;
    Button btnbesinadd;
    ListView besinlist, eklenenbesinlist;

    ArrayList<String> listitem , ikincilist ,deneme;
    ArrayAdapter adapter;

    Databaseyeni db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_besinsearch);

        Intent intent = getIntent();

        final String email = (String) getIntent().getSerializableExtra("email");


        listitem = new ArrayList<>();

        ikincilist = new ArrayList<>();

        deneme = new ArrayList<>();

        db= new Databaseyeni(this);




        searchviv = findViewById(R.id.searchviev);
        besinlist = findViewById(R.id.listviewe);
        eklenenbesinlist = findViewById(R.id.eklenenlist); //alttaki list
        btnbesinadd = findViewById(R.id.btnsave);

        besinlist.setClickable(true);
        eklenenbesinlist.setClickable(true);


        viewData();


        searchviv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                ArrayList<String> foodlist = new ArrayList<>();

                for (String food : listitem){  //Listview datadan doluyor fonksiyonla

                  if(food.toLowerCase().contains(newText.toLowerCase())){

                      foodlist.add(food);
                  }

                }

                ArrayAdapter<String > adapter = new ArrayAdapter<String >(Besinsearch.this, android.R.layout.simple_list_item_1, foodlist );
                besinlist.setAdapter(adapter);


                return true;
            }
        });





        besinlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                ArrayAdapter<String > yeniadapter = new ArrayAdapter<String >(Besinsearch.this, android.R.layout.simple_list_item_1, ikincilist );
                eklenenbesinlist.setAdapter(yeniadapter);



                String ekle = besinlist.getItemAtPosition(position).toString();

                Food data = db.getkalori(ekle);

                String val = String.valueOf(data.getKalori());

                Toast.makeText(getApplicationContext(), val, Toast.LENGTH_SHORT ).show();

                ikincilist.add(ekle);


                yeniadapter.notifyDataSetChanged();


            }

        });

        eklenenbesinlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                ArrayAdapter<String > yeniadapter = new ArrayAdapter<String >(Besinsearch.this, android.R.layout.simple_list_item_1, ikincilist );
                eklenenbesinlist.setAdapter(yeniadapter);

                //adapter hold data dont have to save data again with a function


                String secilen = eklenenbesinlist.getItemAtPosition(position).toString();

                Food fooddata = db.getkalori(secilen);

                String name = fooddata.getFoodname();
                String kalori = String.valueOf(fooddata.getKalori());


                // Toast.makeText(getApplicationContext(), kalori , Toast.LENGTH_LONG).show();



                yeniadapter.remove(secilen);
                yeniadapter.notifyDataSetChanged();


            }
        });


        btnbesinadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int toplam =0;

                for (int i=0; i<ikincilist.size() ;i++){

                    String secilen = eklenenbesinlist.getItemAtPosition(i).toString();

                    Food data = db.getkalori(secilen);

                    int al = data.getKalori();

                    toplam += al;

                }


               String update =  db.UpdateKalori(email, toplam );



               Toast.makeText(getApplicationContext(), update, Toast.LENGTH_SHORT).show();






            }
        });






    }

    private void viewData() {

        Cursor cursor = db.getFood();

        if(cursor.getCount()==0){
            Toast.makeText(getApplicationContext(), "Empty", Toast.LENGTH_SHORT).show();
        }
        else{

            while (cursor.moveToNext()){ //Databaseden gelen besinleri cursora koydum

                listitem.add(cursor.getString(1));
            }

            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listitem );
            besinlist.setAdapter(adapter);


        }


    }




    }



