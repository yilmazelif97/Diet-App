package com.example.welcomepage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.welcomepage.ui.Person;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {


    private static final String CHANNEL_ID = "Channel 1" ;
    private static final String CHANNEL_NAME = "Notification";


    EditText emailtext;
    EditText passwordtext;
    Button login;
    CheckBox cbbenihatirla;
    TextView uyelink, forgotpass;
    static final String My_preferences="com.example.welcomepage";
    Databaseyeni db;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CreateChannel();

        emailtext = findViewById(R.id.etemail);
        passwordtext = findViewById(R.id.sifre);
        login = findViewById(R.id.btngiris);
        cbbenihatirla=findViewById(R.id.cbrememberme);

        uyelink = findViewById(R.id.tvuyelink);
        forgotpass = findViewById(R.id.tvsifreyenileme);

        db= new Databaseyeni(this);


        SharedPreferences prf=getSharedPreferences(My_preferences,MODE_PRIVATE);
        String email =prf.getString("mail","");
        String password =prf.getString("pass","");
        String cbremember =prf.getString("checked","");

        emailtext.setText(email);
        passwordtext.setText(password);
        if (cbbenihatirla.equals("1")){
            cbbenihatirla.setChecked(true);
        }



        uyelink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent uyeintent = new Intent(MainActivity.this, uyeolma.class);

                MainActivity.this.startActivity(uyeintent);

            }
        });

        forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent gec = new Intent(MainActivity.this, newpassword.class);

                MainActivity.this.startActivity(gec);

            }
        });




        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


               String mail = emailtext.getText().toString();
               String password = passwordtext.getText().toString();

               Person persondata = db.getInfo(mail);

               try{

                   Boolean giris = db.emailpasswordcheck(mail,password);

                   if (giris==true){

                       if(cbbenihatirla.isChecked()){

                           SharedPreferences.Editor se=getSharedPreferences(My_preferences,MODE_PRIVATE).edit();
                           se.putString("mail",mail);
                           se.putString("pass",password);
                           se.putString("checked","1");
                           se.commit();
                       }

                       else{
                           SharedPreferences.Editor se=getSharedPreferences(My_preferences,MODE_PRIVATE).edit();
                           se.remove("mail");
                           se.remove("pass");
                           se.remove("checked");
                           se.commit();
                       }


                        Intent gecis = new Intent(MainActivity.this,home_navbar.class);
                        gecis.putExtra("data", persondata);



                       startActivity(gecis);

                        Toast.makeText(getApplicationContext(), "Başarılı giriş", Toast.LENGTH_SHORT ).show();
                   }
                   else if (mail.isEmpty() || password.isEmpty()){
                       Toast.makeText(getApplicationContext(), "Lütfen bilgilerinizi tam giriniz", Toast.LENGTH_SHORT).show();
                   }
                   else {
                       Toast.makeText(getApplicationContext(), "Lütfen üye olun", Toast.LENGTH_SHORT).show();
                   }
               }
               catch (Exception e){

                   Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();

               }




            }
        });




        Intent intent = getIntent();

    }

    private void CreateChannel() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

}


//Üye Giriş Sayfası