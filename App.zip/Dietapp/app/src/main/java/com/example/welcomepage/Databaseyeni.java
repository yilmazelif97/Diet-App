package com.example.welcomepage;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.welcomepage.ui.Person;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Databaseyeni extends SQLiteOpenHelper {

    public static final String databasename = "yenidata.db";
    public static final String tablename = "user";
    public static final String col1 = "userid";
    public static final String col2 = "isim";
    public static final String col3 = "soyisim";
    public static final String col4 = "email";
    public static final String col5 = "sifre";
    public static final String col6 = "yas";
    public static final String col7 = "cinsiyet";
    public static final String col8 = "boy";
    public static final String col9 = "guncelkilo";
    public static final String col10 = "idealkilo";
    public static final String col11= "kalori";

    public static final String table2 = "besin";
    public static final String besinid = "besinid";
    public static final String besinad = "besinad";
    public static final String besinkalori = "besinkaori";



    public Databaseyeni(@Nullable Context context) {
        super(context, databasename, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) { //database oluşturmaya yardımcı

        db.execSQL(" CREATE TABLE " + tablename + "("
                + col1 + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + col2  + " TEXT, "
                + col3 +" TEXT, "
                + col4 + " TEXT, "
                +col5 + " TEXT, "
                +col6 +" INTEGER, "
                +col7 + " TEXT, "
                + col8  + " INTEGER, "
                + col9 + " INTEGER, "
                + col10 + " INTEGER, "
                + col11 + " INTEGER)");

        db.execSQL(" CREATE TABLE " + table2 + "("
                + besinid + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + besinad  + " TEXT, "
                +besinkalori +" INTEGER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { //databasede güncelleme varsa çalışır


        db.execSQL(" DROP TABLE IF EXISTS " + tablename);
        db.execSQL(" DROP TABLE IF EXISTS " +table2);





        onCreate(db);

    }

    public boolean emailpasswordcheck(String mail, String password){

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " +tablename +" WHERE email=? AND sifre=? ", new String[]{mail,password} );
        if (cursor.getCount()>0){
            return true;
        }
        else {

            return false;
        }

    }



    public Person getInfo(String email){

        SQLiteDatabase db = this.getReadableDatabase();
        Person data = null;

        Cursor c = db.rawQuery("SELECT * FROM " + tablename + " WHERE email = ? ", new String[]{(email)});

        if (c != null) {
            while (c.moveToNext()) {
                data = new Person(c.getInt(0),c.getString(1),c.getString(2),c.getString(3)
                        ,c.getString(4),c.getInt(5),c.getString(6),c.getInt(7),c.getInt(8),c.getInt(9),c.getInt(10));
            }
            c.close();

        }

        return data;

    }

    public String Updateuser(int id,String name, String soyisim, String email, String password, String cinsiyet,int boy,int yas ) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(col2, name);
        values.put(col3, soyisim);
        values.put(col4, email);
        values.put(col5, password);
        values.put(col7, cinsiyet);
        values.put(col8, boy);
        values.put(col6, yas);


        String whereArgs[] = new String[]{String.valueOf(id)};

        long result = db.update(tablename, values, " userid=? ", whereArgs);

        String msg = "Not Updated";
        if (result > 0) {
            msg = "Updated successfully";
        }
        return msg;

    }

    public boolean checkemailformat(String email) {

        Pattern pattern;
        Matcher matcher;
        String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();

    }


    public Boolean SearchMail(String mail){
        SQLiteDatabase db =this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + tablename + " WHERE email = ? ", new String[]{(mail)});


        if (c.getCount()>0){
            return true;
        }
        else {

            return false;
        }


    }


    public String UpdatePassword(String email, String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(col5, password);

        String whereArgs[] = new String[]{(email)};

        long result = db.update(tablename, values, " email=? ", whereArgs);

        String msg = "Bilgiler Güncellenemedi";
        if (result > 0) {
            msg = "Şifreniz Yenilendi";
        }
        return msg;

    }

    public boolean checkemail(String email) {

        Pattern pattern;
        Matcher matcher;
        String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);
        return matcher.matches();

    }

    public Cursor getFood(){

        SQLiteDatabase db = this.getReadableDatabase();

        String query = " SELECT * FROM "+ table2;

        Cursor c = db.rawQuery(query,null);


        return c;

    }

    public Cursor SearchbyName(String name){
        SQLiteDatabase db =this.getReadableDatabase();
        String query="SELECT * FROM " + table2 + "where " + besinad + "Like '%"+name+"%'";
        Cursor cursor =db.rawQuery(query,null);
        return cursor;
    }



    public Cursor SearchonList(String isim){  //girilen ismin kalorisini buluyor.
        SQLiteDatabase db = this.getReadableDatabase();
        String query="SELECT besinkalori FROM " + table2 + "where " + besinad + "Like '%"+isim+"%'";

        Cursor cursor = db.rawQuery(query, null);

        int deger = cursor.getInt(0);

        return cursor;

    }

    public Food getkalori(String isim){

        SQLiteDatabase db = this.getReadableDatabase();
        Food data = null;

        Cursor c = db.rawQuery("SELECT * FROM " + table2 + " WHERE besinad = ? ", new String[]{(isim)});

        if (c != null) {
            while (c.moveToNext()) {
                data = new Food(c.getInt(0),c.getString(1),c.getInt(2));
            }
            c.close();

        }

        return data;

    }



    public String UpdateKalori(String email, int kalori) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(col11, kalori);

        String whereArgs[] = new String[]{(email)};

        long result = db.update(tablename, values, " email=? ", whereArgs);

        String msg = "Kalori güncellenemedi";
        if (result > 0) {
            msg = "Kalori Eklendi";
        }
        return msg;

    }

    public Cursor Personcal(String email){  //Giriş yapan mailin kalorisini buluyor
        SQLiteDatabase db = this.getReadableDatabase();

        String query="SELECT col11 FROM " + tablename + "where " + col4 + "Like '%"+email+"%'";

        Cursor cursor = db.rawQuery(query, null);

        int deger = cursor.getInt(10);

        return cursor;

    }

    public int getKal(String email){

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + tablename + " WHERE email = ? ", new String[]{(email)});

        int deger = c.getInt(10);


        return deger;
    }














}
