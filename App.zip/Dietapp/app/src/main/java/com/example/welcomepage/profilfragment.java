package com.example.welcomepage;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.style.UpdateLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.welcomepage.R;



public class profilfragment extends Fragment implements View.OnClickListener {

    ImageButton cikisbutonu;
    private View rootview;
    EditText etisim,etsoyisim,etemail,etpassword, etyas, etcinsiyet, etboy, etid;
    Button btnupdate ,btnkalori;
    RadioGroup rg;
    RadioButton rbkadin, rberkek;
    Boolean erkek=false;



    Databaseyeni db;


    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootview = inflater.inflate(R.layout.fragment_profil_fragment, container, false);

        db= new Databaseyeni(this.getActivity());



        String isim = getArguments().getString("isim");
        String soyad = getArguments().getString("soyisim");
        final String mail = getArguments().getString("email");
        String sifre = getArguments().getString("sifre");
        String yas = getArguments().getString("yas");
        String boy = getArguments().getString("boy");
        String cinsiyet = getArguments().getString("cinsiyet");

        String idealkilo = getArguments().getString("idealkilo");

        String id = getArguments().getString("id");



        etisim= rootview.findViewById(R.id.etİsim);
        etsoyisim= rootview.findViewById(R.id.etSoyİsim);
        etemail= rootview.findViewById(R.id.etMail);
        etpassword= rootview.findViewById(R.id.etSifre);
        etyas= rootview.findViewById(R.id.etYas);
        etboy= rootview.findViewById(R.id.etBoy);
        rg=rootview.findViewById(R.id.rgroupcinsiyet);
        rberkek=rootview.findViewById(R.id.rberkek);
        rbkadin=rootview.findViewById(R.id.rbkadin);
        etcinsiyet=rootview.findViewById(R.id.etcins);
        etid= rootview.findViewById(R.id.datid);

        btnupdate = rootview.findViewById(R.id.btnDegisiklikkayit);
        btnkalori = rootview.findViewById(R.id.btnKaloriTakvim);

        etid.setText(id);
        etisim.setText(isim);
        etsoyisim.setText(soyad);
        etemail.setText(mail);
        etpassword.setText(sifre);
        etyas.setText(yas);
        etboy.setText(boy);
        etcinsiyet.setText(cinsiyet);

        btnupdate.setOnClickListener(this);


        btnkalori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent gecis = new Intent(getActivity(), Grafik.class);

                gecis.putExtra("email", mail);

                startActivity(gecis);

            }
        });





        cikisbutonu = (ImageButton) rootview.findViewById(R.id.ibCikis);

        cikisbutonu.setOnClickListener(new View.OnClickListener() { //Butonu tıkladığımda gerçkeleşecekleri yaz
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder  = new AlertDialog.Builder(getActivity());
                builder.setMessage("Uyarı \n"+ "Çıkış yapmak istiyor musunuz");
                builder.setCancelable(true);

                builder.setNegativeButton("Hayır", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.setPositiveButton("Evet", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent cikisintent = new Intent(getActivity().getApplication(), MainActivity.class);

                        profilfragment.this.startActivity(cikisintent);

                    }
                });

                AlertDialog dialog =  builder.create();
                dialog.show();



            }
        });


        return rootview;


    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnDegisiklikkayit:

                int id2 = Integer.parseInt(etid.getText().toString());
                String isim2 = etisim.getText().toString();
                String soyisim2 = etsoyisim.getText().toString();
                String email2 = etemail.getText().toString();
                String pass = etpassword.getText().toString();
                int yas2 = Integer.parseInt(etyas.getText().toString());
                int boy2 = Integer.parseInt(etboy.getText().toString());


                RadioButton checkbtn = rootview.findViewById(rg.getCheckedRadioButtonId());
                String cinsiyet2 = checkbtn.getText().toString();


                try {


                    Toast.makeText(getActivity(), db.Updateuser(id2,isim2,soyisim2,email2,pass,cinsiyet2,boy2,yas2) , Toast.LENGTH_SHORT).show();

                    Fragment currentFragment = getFragmentManager().findFragmentById(R.id.fragmentContainer);
                    FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                    fragmentTransaction.detach(currentFragment);
                    fragmentTransaction.attach(currentFragment);
                    fragmentTransaction.commit();


                }
                catch (Exception e){
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }



                break;
        }

    }




}
