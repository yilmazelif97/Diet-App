package com.example.welcomepage;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.welcomepage.R;
import com.example.welcomepage.ui.Person;


public class kalorifragment extends Fragment {

    TextView tvalinankalori, tvlimitkalori;
    private View rootview;

    Databaseyeni db;




    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootview = inflater.inflate(R.layout.fragment_kalori_fragment, container, false);

        db= new Databaseyeni(this.getActivity());



        String alinankal = getArguments().getString("kalori");

        int gelkal = Integer.parseInt(alinankal);

        int boy = Integer.parseInt(getArguments().getString("boy"));
        int yas = Integer.parseInt(getArguments().getString("yas"));
        int kilo = Integer.parseInt(getArguments().getString("kilo"));
        String email = getArguments().getString("email");


        int needcal = (int) (66+ (9.6*kilo)+(1.7*boy)+ (4.7*yas));

        String needcalori = String.valueOf(needcal);

        Person p = db.getInfo(email); // Giriş yapılan dataabsedeki kalori tutulduğu için refresh etmek adına bunu kullandım
        int calori = p.getKalori();
        String alinancal = String.valueOf(calori);

        tvalinankalori= rootview.findViewById(R.id.tvdatakalori);
        tvlimitkalori = rootview.findViewById(R.id.tvgereklikalori);

        tvalinankalori.setText(alinancal);
        tvlimitkalori.setText(needcalori);




        if(calori > needcal){

            //Toast.makeText(getActivity(), "Kalori aşımı", Toast.LENGTH_SHORT).show();

            AlertDialog.Builder builder  = new AlertDialog.Builder(getActivity());
            builder.setMessage("Uyarı \n"+ "Kalori Aşımı");
            builder.setCancelable(true);

            builder.setNegativeButton("Tamam", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });



            AlertDialog dialog =  builder.create();
            dialog.show();



        }



        return rootview;



    }





        }




