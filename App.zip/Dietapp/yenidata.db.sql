BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "besin" (
	"besinid"	INTEGER PRIMARY KEY AUTOINCREMENT,
	"besinad"	TEXT,
	"besinkaori"	INTEGER
);
CREATE TABLE IF NOT EXISTS "user" (
	"userid"	INTEGER PRIMARY KEY AUTOINCREMENT,
	"isim"	TEXT,
	"soyisim"	TEXT,
	"email"	TEXT,
	"sifre"	TEXT,
	"yas"	INTEGER,
	"cinsiyet"	TEXT,
	"boy"	INTEGER,
	"guncelkilo"	INTEGER,
	"idealkilo"	INTEGER,
	"kalori"	INTEGER
);
CREATE TABLE IF NOT EXISTS "android_metadata" (
	"locale"	TEXT
);
INSERT INTO "besin" VALUES (1,'Ekmek',50);
INSERT INTO "besin" VALUES (2,'Yoğurt',150);
INSERT INTO "user" VALUES (1,'ali','ahmet','a','a',26,'Erkek',150,60,43,NULL);
INSERT INTO "user" VALUES (2,'b','b','b','b',25,'Kadın',160,58,52,NULL);
INSERT INTO "user" VALUES (3,'c','c','c','c',23,'Erkek',170,65,65,NULL);
INSERT INTO "user" VALUES (4,'elif','yilmaz','elif','12345',23,'Kadın',170,60,61,NULL);
INSERT INTO "user" VALUES (5,'elif','yilmaz','elif','12345',26,'Erkek',175,58,61,NULL);
INSERT INTO "user" VALUES (6,'e','y','elif','12345',23,'Kadın',170,58,61,NULL);
INSERT INTO "user" VALUES (7,'elif','yilmaz','elifyilmaz','123',23,'Kadın',170,58,61,NULL);
INSERT INTO "user" VALUES (8,'elif','yilmaz','elify','12',23,'Kadın',170,58,61,NULL);
INSERT INTO "user" VALUES (9,'elif','yilmaz','e','elif123',26,'Erkek',160,58,61,NULL);
INSERT INTO "user" VALUES (10,'o','o','o','o',23,'Kadın',160,56,52,NULL);
INSERT INTO "user" VALUES (11,'k','k','kl','kl',23,'Erkek',185,96,79,NULL);
INSERT INTO "user" VALUES (12,'p','p','kklk@gmail.com','123',23,'Erkek',165,100,61,NULL);
INSERT INTO "android_metadata" VALUES ('en_US');
COMMIT;
